/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * New_recruitment.java
 *
 * Created on Jan 1, 2002, 10:07:47 AM
 */

package officeautomation;
import java.sql.*;
import javax.swing.JOptionPane;

public class New_recruitment extends javax.swing.JFrame {

   
    public New_recruitment() {
        initComponents();
    }
    Connection con=null;
   String name,dob,gender,address,phoneno,department,grade,doj;
   String id,age;
   String str,str2,srchid;
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jTextField2 = new javax.swing.JTextField();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jTextField9 = new javax.swing.JTextField();
        userid = new javax.swing.JLabel();
        nam_lab = new javax.swing.JLabel();
        ag_lab = new javax.swing.JLabel();
        add_lab = new javax.swing.JLabel();
        ph_lab = new javax.swing.JLabel();
        dep_lab = new javax.swing.JLabel();
        gd_lab = new javax.swing.JLabel();
        doj_lab = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        gtadress = new javax.swing.JTextArea();
        gtid = new javax.swing.JTextField();
        gtnam = new javax.swing.JTextField();
        gtage = new javax.swing.JTextField();
        gtdepart = new javax.swing.JTextField();
        getgrd = new javax.swing.JTextField();
        dob_lab = new javax.swing.JLabel();
        enter_staff_detail = new javax.swing.JButton();
        gen_lab = new javax.swing.JLabel();
        male_rb = new javax.swing.JRadioButton();
        female_rb = new javax.swing.JRadioButton();
        gtdobfield = new javax.swing.JFormattedTextField();
        gtphon = new javax.swing.JFormattedTextField();
        gtdoj = new javax.swing.JFormattedTextField();

        jTextField1.setText("jTextField1");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jTextField2.setText("jTextField2");

        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("New recruitment");

        userid.setText("ID:");

        nam_lab.setText("Name:");

        ag_lab.setText("Age:");

        add_lab.setText("Address:");

        ph_lab.setText("Phone no:");

        dep_lab.setText("Department:");

        gd_lab.setText("Grade:");

        doj_lab.setText("Date of joining:");

        gtadress.setColumns(20);
        gtadress.setLineWrap(true);
        gtadress.setRows(5);
        gtadress.setWrapStyleWord(true);
        jScrollPane2.setViewportView(gtadress);

        gtid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gtidActionPerformed(evt);
            }
        });

        gtnam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gtnamActionPerformed(evt);
            }
        });

        gtage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gtageActionPerformed(evt);
            }
        });

        dob_lab.setText("Date of Birth:");

        enter_staff_detail.setText("OK");
        enter_staff_detail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enter_staff_detailActionPerformed(evt);
            }
        });

        gen_lab.setText("Gender");

        buttonGroup1.add(male_rb);
        male_rb.setText("MALE");
        male_rb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                male_rbActionPerformed(evt);
            }
        });

        buttonGroup1.add(female_rb);
        female_rb.setText("FEMALE");
        female_rb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                female_rbActionPerformed(evt);
            }
        });

        gtdobfield.setColumns(10);
        try {
            gtdobfield.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##-##-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        gtdobfield.setToolTipText("MM\\DD\\YY");

        gtphon.setColumns(12);
        try {
            gtphon.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##-##########")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        gtphon.setToolTipText("WITH COUNTRY CODE");
        gtphon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gtphonActionPerformed(evt);
            }
        });

        gtdoj.setColumns(12);
        try {
            gtdoj.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##-##-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        gtdoj.setToolTipText("DD\\MM\\YY");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(enter_staff_detail, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(doj_lab)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(gtdoj, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(dep_lab)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(ph_lab)
                                    .addComponent(gd_lab)
                                    .addComponent(add_lab)
                                    .addComponent(ag_lab)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(userid, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(nam_lab)))
                                .addGap(30, 30, 30)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(gtphon, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(gtid, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                                        .addComponent(gtnam, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(gtage, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(54, 54, 54)
                                            .addComponent(dob_lab)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(gtdobfield, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE))
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                                        .addComponent(getgrd, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                                        .addComponent(gtdepart, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                            .addComponent(male_rb)
                                            .addGap(46, 46, 46)
                                            .addComponent(female_rb))))))
                        .addGap(21, 21, 21))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(gen_lab)
                        .addContainerGap(346, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(nam_lab)
                        .addGap(18, 18, 18)
                        .addComponent(ag_lab)
                        .addGap(21, 21, 21))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(userid)
                            .addComponent(gtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(gtnam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(gtage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dob_lab)
                            .addComponent(gtdobfield, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gen_lab)
                    .addComponent(male_rb)
                    .addComponent(female_rb))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(add_lab)
                        .addGap(100, 100, 100)
                        .addComponent(ph_lab))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(gtphon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dep_lab)
                    .addComponent(gtdepart, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gd_lab)
                    .addComponent(getgrd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(doj_lab)
                    .addComponent(gtdoj, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(enter_staff_detail)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void gtidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gtidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gtidActionPerformed

    private void gtnamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gtnamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gtnamActionPerformed

    private void gtageActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gtageActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gtageActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void enter_staff_detailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enter_staff_detailActionPerformed
        id=gtid.getText();
        name=gtnam.getText();
        age=gtage.getText();
        dob=gtdobfield.getText();
        address=gtadress.getText();
        phoneno=gtphon.getText();
        department=gtdepart.getText();
        grade=gtage.getText();
        doj=gtdoj.getText();
        
        MysqlDb db=new MysqlDb();
        con=db.connmysql();
         try{
             Statement stid=con.createStatement();
             ResultSet rtid=stid.executeQuery("Select * from staffdetails where idstaff='"+id+"';");
             if(rtid.next())
                {
                    srchid=(rtid.getString("idstaff"));
                }
        rtid.close();
        stid.close();
        
     System.out.println(srchid);
    
      if(  ( !gtid.getText().equals(srchid)) && (id != null))  
      {
          
           str="insert into staffdetails (idstaff,Name,Age,DOB,Gender,Address,Department,Grade,DOJ) value (?,?,?,?,?,?,?,?,?) ;";
            
           PreparedStatement pst=con.prepareStatement(str);
           pst.setString(1, id);
           pst.setString(2, name);
           pst.setString(3, age);
           pst.setString(4, dob);
           pst.setString(5, gender);
           pst.setString(6, address);
           pst.setString(7, department);
           pst.setString(8, grade);
           pst.setString(9, doj);
           
           pst.execute();
           str2="insert into user (idstaff,username,password) value (?,?,?) ;";
           PreparedStatement pst2=con.prepareStatement(str2);
           pst2.setString(1, id);
           pst2.setString(2, name);
           pst2.setString(3, name);
           pst2.execute();
          
           
         JOptionPane.showMessageDialog(null,"DETAILS SAVED");
          }
       else
      {
       JOptionPane.showMessageDialog(null,"Id already exist");   
      }
        
      } 
     
       catch(Exception e)
       {
           System.out.println(e);
           JOptionPane.showMessageDialog(null,"Enter details completely");
      
       }
        
    }//GEN-LAST:event_enter_staff_detailActionPerformed

    private void male_rbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_male_rbActionPerformed
       gender="MALE";
    }//GEN-LAST:event_male_rbActionPerformed

    private void gtphonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gtphonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_gtphonActionPerformed

    private void female_rbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_female_rbActionPerformed
        gender="FEMALE";
    }//GEN-LAST:event_female_rbActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new New_recruitment().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel add_lab;
    private javax.swing.JLabel ag_lab;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel dep_lab;
    private javax.swing.JLabel dob_lab;
    private javax.swing.JLabel doj_lab;
    private javax.swing.JButton enter_staff_detail;
    private javax.swing.JRadioButton female_rb;
    private javax.swing.JLabel gd_lab;
    private javax.swing.JLabel gen_lab;
    private javax.swing.JTextField getgrd;
    private javax.swing.JTextArea gtadress;
    private javax.swing.JTextField gtage;
    private javax.swing.JTextField gtdepart;
    private javax.swing.JFormattedTextField gtdobfield;
    private javax.swing.JFormattedTextField gtdoj;
    private javax.swing.JTextField gtid;
    private javax.swing.JTextField gtnam;
    private javax.swing.JFormattedTextField gtphon;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JRadioButton male_rb;
    private javax.swing.JLabel nam_lab;
    private javax.swing.JLabel ph_lab;
    private javax.swing.JLabel userid;
    // End of variables declaration//GEN-END:variables

}
