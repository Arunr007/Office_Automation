/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package officeautomation;
import java.sql.*;

public class MysqlDb {
    Connection conn;
    
    public Connection connmysql()
    {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            
           conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/officedb","root","");
           System.out.println(); 
            }
        catch(Exception e)
        {
           
        }
        return conn;
    }
}
