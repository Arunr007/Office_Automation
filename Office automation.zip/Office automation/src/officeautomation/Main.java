/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package officeautomation;
import officeautomation.MysqlDb.*;
import officeautomation.login.*;
/**
 *
 * @author PC8
 */
public class Main {

   
    public static void main(String[] args) {
         java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
}
}
