/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Salary_details.java
 *
 * Created on Jan 1, 2002, 10:57:32 AM
 */

package officeautomation;

import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author PC8
 */
public class Salary_details extends javax.swing.JFrame {
 Connection conn;
    String id,up,srchid,gd,str,sql1,sql2,ba,da,hra,tax,tot;
   double  bad,dad,hrad,taxd,totd;
    public Salary_details() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        entry_btn = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        bst = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        taxt = new javax.swing.JTextField();
        tott = new javax.swing.JTextField();
        gdtxt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        dat = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        hrat = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        id_lab = new javax.swing.JLabel();
        id_search = new javax.swing.JButton();
        idtxt = new javax.swing.JTextField();
        update = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("SALARY DETAILS");
        setBackground(new java.awt.Color(255, 255, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        entry_btn.setText("ENTRY");
        entry_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entry_btnActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(-1,true));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(-16777216,true)));
        jPanel1.setForeground(new java.awt.Color(-1,true));

        jLabel2.setText("Base Salary");

        tott.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tottActionPerformed(evt);
            }
        });

        jLabel5.setText("TAX");

        jLabel6.setText("TOTAL");

        jLabel3.setText("D A");

        jLabel4.setText("H R A");

        jLabel1.setText("Grade");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(dat, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(hrat, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(taxt, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tott, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(gdtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bst, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addComponent(gdtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(bst, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(dat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(hrat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(taxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tott, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("SEARCH "));

        id_lab.setText("ID:");

        id_search.setText("SEARCH");
        id_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_searchActionPerformed(evt);
            }
        });

        idtxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idtxtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(id_lab)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(idtxt, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(id_search)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(id_lab)
                    .addComponent(idtxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(id_search))
                .addContainerGap())
        );

        update.setText("UPDATE");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(update)
                        .addGap(18, 18, 18)
                        .addComponent(entry_btn))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(97, 97, 97))
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(38, 38, 38))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(entry_btn)
                    .addComponent(update))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void calc()
    {
        bad=Double.parseDouble(bst.getText());
        dad=Double.parseDouble(dat.getText());
        hrad=Double.parseDouble(hrat.getText());
        taxd=Double.parseDouble(taxt.getText());
        totd=(bad+dad+hrad)-((bad*taxd)/100);
        System.out.println(totd);
    }
    private void entry_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_entry_btnActionPerformed
        
        calc();
        
        this.tott.setText((String.valueOf(totd)));
       ba=bst.getText();
       da=dat.getText();
       hra=hrat.getText();
       tax=taxt.getText();
       tot=String.valueOf(totd);
         MysqlDb db=new MysqlDb();
        conn=db.connmysql();
         try{ 
             id=idtxt.getText();
             
           sql1="select * from salary where idstaff='"+id+"';";
            Statement st1=conn.createStatement();
             ResultSet rs1=st1.executeQuery(sql1);
             if(rs1.next())
             {
                 srchid=rs1.getString("idstaff");
                 }
             rs1.close();
             st1.close();
             
           if(  ( !id.equals(srchid)) && (id != null))  
      {   
             str="insert into salary (idstaff,BS,DA,HRA,TAX,TOTAL) value (?,?,?,?,?,?) ;";
            
           PreparedStatement pst=conn.prepareStatement(str);
           pst.setString(1, id);
           pst.setString(2, ba);
           pst.setString(3, da);
           pst.setString(4, hra);
           pst.setString(5, tax);
           pst.setString(6, tot);
           
           pst.execute();
      }
           else{
               JOptionPane.showMessageDialog(null,"ID ALREADY EXIST");
           }
         conn.close();  
         }
         catch (Exception e)
         {
             System.out.println(e);
         }
        
    }//GEN-LAST:event_entry_btnActionPerformed

    private void idtxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idtxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idtxtActionPerformed

    private void id_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_searchActionPerformed
        MysqlDb md=new MysqlDb();
        conn=md.connmysql();
        
        id=idtxt.getText();
        try
        {    sql1="select * from salary where idstaff='"+id+"';";
             sql2="select * from staffdetails where idstaff='"+id+"';";
            Statement st=conn.createStatement();
            
            ResultSet rs=st.executeQuery(sql1);
            if(rs.next())
            {
                ba=rs.getString("BS");
                da=rs.getString("DA");
                hra=rs.getString("HRA");
                tax=rs.getString("TAX");
                tot=rs.getString("TOTAL");
            }
            rs.close();
            st.close();
            Statement st1=conn.createStatement();
             ResultSet rs1=st1.executeQuery(sql2);
             if(rs1.next())
             {
                 gd=rs1.getString("Grade");
                 }
             rs1.close();
             st1.close();
             conn.close();
             this.bst.setText(ba);
             this.dat.setText(da);
             this.hrat.setText(hra);
             this.taxt.setText(tax);
             this.tott.setText(tot);
             this.gdtxt.setText(gd);
             if(ba==null && gd==null)
             {
               JOptionPane.showMessageDialog(null,"No details Not found for ID:  " +id );  
             }
             
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"No details Not found for ID:  " +id );
        }
    }//GEN-LAST:event_id_searchActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
          MysqlDb mb=new MysqlDb();
        conn=mb.connmysql();
        id=idtxt.getText();
        this.calc();
        System.out.println(totd);
         this.tott.setText((String.valueOf(totd)));
       try{
           up="update salary set BS=?,DA=?,HRA=?,TAX=?,TOTAL=? where idstaff='"+id+"';";
           PreparedStatement pt=conn.prepareStatement(up);
            pt.setString(1, bst.getText());
           pt.setString(2, dat.getText());
           pt.setString(3, hrat.getText());
           pt.setString(4, taxt.getText());
           pt.setString(5, String.valueOf(totd));
           
         pt.executeUpdate();  
        JOptionPane.showMessageDialog(null,"DETAILS UPDATED"); 
       }
        catch(Exception e)
       {
           System.out.println(e);
           JOptionPane.showMessageDialog(null,"ID not specified");
           
       }
    }//GEN-LAST:event_updateActionPerformed

    private void tottActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tottActionPerformed
        calc();
        this.tott.setText((String.valueOf(totd))); 
    }//GEN-LAST:event_tottActionPerformed

    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Salary_details().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bst;
    private javax.swing.JTextField dat;
    private javax.swing.JButton entry_btn;
    private javax.swing.JTextField gdtxt;
    private javax.swing.JTextField hrat;
    private javax.swing.JLabel id_lab;
    private javax.swing.JButton id_search;
    private javax.swing.JTextField idtxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField taxt;
    private javax.swing.JTextField tott;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables

}
